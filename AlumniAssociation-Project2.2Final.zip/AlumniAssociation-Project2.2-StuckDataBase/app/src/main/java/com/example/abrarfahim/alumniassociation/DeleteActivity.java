package com.example.abrarfahim.alumniassociation;

import android.content.ContentUris;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class DeleteActivity extends AppCompatActivity {
    EditText editRollSearch;
    TextView textStudentName,textGraduation,textBatchYear,textCurrentCity,textProfession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        textStudentName =(TextView) findViewById(R.id.textViewDeleteName);
        editRollSearch=(EditText) findViewById(R.id.editTextEditRollCheck);
        textGraduation=(TextView) findViewById(R.id.textViewDeleteGraduation);
        textBatchYear=(TextView) findViewById(R.id.textViewDeleteBatch);
        textCurrentCity=(TextView) findViewById(R.id.textViewDeleteCurrentCity);
        textProfession=(TextView) findViewById(R.id.textViewDeleteProfession);
    }

    public void backButtonClicked(View v) {
        finish();
    }

    public void onClickDeleteCheck(View view) {
        String URL="content://com.example.abrarfahim.alumniassociation.DBHandler";
        String[] columnContents=new String[]{
                DBHandler.NAME,
                DBHandler.YEAR,
                DBHandler.BATCH_YEAR,
                DBHandler.CURRENT_CITY,
                DBHandler.PROFESSION,
                DBHandler.EMAIL,
                DBHandler.ROLL_NO};
        String searchByRoll=DBHandler.ROLL_NO+" = ?";
        Cursor c=getContentResolver().query(DBHandler.CONTENT_URI,columnContents, searchByRoll,new String[] {editRollSearch.getText().toString()},null);
        if(c!=null&&c.getCount()>0) {
            while(c.moveToNext()) {
                textStudentName.setText(c.getString(c.getColumnIndex(DBHandler.NAME)));
                textGraduation.setText(c.getString(c.getColumnIndex(DBHandler.YEAR)));
                textBatchYear.setText(c.getString(c.getColumnIndex(DBHandler.BATCH_YEAR)));
                textCurrentCity.setText(c.getString(c.getColumnIndex(DBHandler.CURRENT_CITY)));
                textProfession.setText(c.getString(c.getColumnIndex(DBHandler.PROFESSION)));
            }
            view=findViewById(R.id.button);
            view.setVisibility(View.VISIBLE);
        }
        else {
            AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
            wrongRollAlert.setTitle("Error!");
            wrongRollAlert.setMessage("You're checking an invalid roll no.\nEnter a valid roll no.\nPress Ok to continue.");
            wrongRollAlert.setPositiveButton("Ok",null);
            wrongRollAlert.setCancelable(true);
            wrongRollAlert.create().show();
            wrongRollAlert.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            editRollSearch.setText("");
            textStudentName.setText("");
            textGraduation.setText("");
            textBatchYear.setText("");
            textCurrentCity.setText("");
            textProfession.setText("");
        }
    }
    public void deleteButtonClicked(View v) {
        String searchByRoll=DBHandler.ROLL_NO+" = ?";
        int deleteCount=getContentResolver().delete(DBHandler.CONTENT_URI,searchByRoll,new String[] {editRollSearch.getText().toString()});
        AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
        wrongRollAlert.setTitle("Successfully Deleted!");
        wrongRollAlert.setMessage("The student recorded is deleted successfully.\nRecord deleted "+deleteCount+" times.\nPress Ok to continue.");
        wrongRollAlert.setPositiveButton("Ok",null);
        wrongRollAlert.setCancelable(true);
        wrongRollAlert.create().show();
        wrongRollAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        editRollSearch.setText("");
        textStudentName.setText("");
        textGraduation.setText("");
        textBatchYear.setText("");
        textCurrentCity.setText("");
        textProfession.setText("");
    }
}
