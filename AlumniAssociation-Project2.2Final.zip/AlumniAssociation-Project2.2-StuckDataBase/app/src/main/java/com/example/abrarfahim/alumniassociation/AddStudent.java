package com.example.abrarfahim.alumniassociation;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddStudent extends AppCompatActivity {
    EditText editStudentName,editGraduationYear,editBatchYear,editCurrentCity,editProfession,editEmail,editRollNo;
    Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        editStudentName=(EditText) findViewById(R.id.editTextEditRollCheck);
        editGraduationYear=(EditText) findViewById(R.id.editTextGraduationYear);
        editBatchYear=(EditText) findViewById(R.id.editText5);
        editCurrentCity=(EditText) findViewById(R.id.editTextCurrentCity);
        editProfession=(EditText) findViewById(R.id.editTextProfession);
        editEmail=(EditText) findViewById(R.id.editText7);
        editRollNo=(EditText) findViewById(R.id.editTextRollNo);
        addButton=(Button) findViewById(R.id.button2);
    }

    public void onClickBackButton(View v) {
        finish();
    }

    public void onClickAddButton(View v) {
        ContentValues values = new ContentValues();
        values.put(DBHandler.NAME,
                editStudentName.getText().toString());
        values.put(DBHandler.YEAR,
                editGraduationYear.getText().toString());
        values.put(DBHandler.BATCH_YEAR,
                editBatchYear.getText().toString());
        values.put(DBHandler.CURRENT_CITY,
                editCurrentCity.getText().toString());
        values.put(DBHandler.PROFESSION,
                editProfession.getText().toString());
        values.put(DBHandler.EMAIL,
                editEmail.getText().toString());
        values.put(DBHandler.ROLL_NO,
                editRollNo.getText().toString());

        Uri uri = getContentResolver().insert(
                DBHandler.CONTENT_URI, values);

        AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
        wrongRollAlert.setTitle("Successfully Added!");
        wrongRollAlert.setMessage("The student recorded is added successfully.\nPress Ok to continue.");
        wrongRollAlert.setPositiveButton("Ok",null);
        wrongRollAlert.setCancelable(true);
        wrongRollAlert.create().show();
        wrongRollAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        editStudentName.setText("");
        editGraduationYear.setText("");
        editBatchYear.setText("");
        editCurrentCity.setText("");
        editProfession.setText("");
        editEmail.setText("");
        editRollNo.setText("");
    }
}
