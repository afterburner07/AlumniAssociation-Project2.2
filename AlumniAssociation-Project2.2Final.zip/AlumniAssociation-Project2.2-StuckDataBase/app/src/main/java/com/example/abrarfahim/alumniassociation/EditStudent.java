package com.example.abrarfahim.alumniassociation;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class EditStudent extends AppCompatActivity {

    EditText editRollSearch,editStudentName,editGraduationYear,editBatchYear,editCurrentCity,editProfession,editEmail,editRollNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student);
        editRollSearch=(EditText) findViewById(R.id.editTextEditRollCheck);
        editStudentName=(EditText) findViewById(R.id.editTextStudentName);
        editGraduationYear=(EditText) findViewById(R.id.editTextGraduationYear);
        editBatchYear=(EditText) findViewById(R.id.editTextBatchYear);
        editCurrentCity=(EditText) findViewById(R.id.editTextCurrentCity);
        editProfession=(EditText) findViewById(R.id.editTextProfession);
        editEmail=(EditText) findViewById(R.id.editTextEmail);
        editRollNo=(EditText) findViewById(R.id.editTextRollNo);
    }

    public void onClickCancelButton(View v) {
        finish();
    }

    public void onClickCheck(View v) {
        String URL="content://com.example.abrarfahim.alumniassociation.DBHandler";
        String[] columnContents=new String[]{
                DBHandler.NAME,
                DBHandler.YEAR,
                DBHandler.BATCH_YEAR,
                DBHandler.CURRENT_CITY,
                DBHandler.PROFESSION,
                DBHandler.EMAIL,
                DBHandler.ROLL_NO};
        String searchByRoll=DBHandler.ROLL_NO+" = ?";
        Cursor c=getContentResolver().query(DBHandler.CONTENT_URI,columnContents, searchByRoll,new String[] {editRollSearch.getText().toString()},null);
        if(c!=null&&c.getCount()>0) {
            while(c.moveToNext()) {
                editStudentName.setText(c.getString(c.getColumnIndex(DBHandler.NAME)));
                editGraduationYear.setText(c.getString(c.getColumnIndex(DBHandler.YEAR)));
                editBatchYear.setText(c.getString(c.getColumnIndex(DBHandler.BATCH_YEAR)));
                editCurrentCity.setText(c.getString(c.getColumnIndex(DBHandler.CURRENT_CITY)));
                editProfession.setText(c.getString(c.getColumnIndex(DBHandler.PROFESSION)));
                editEmail.setText(c.getString(c.getColumnIndex(DBHandler.EMAIL)));
                editRollNo.setText(c.getString(c.getColumnIndex(DBHandler.ROLL_NO)));
            }
            v=findViewById(R.id.button2);
            v.setVisibility(View.VISIBLE);
        }
        else {
            AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
            wrongRollAlert.setTitle("Error!");
            wrongRollAlert.setMessage("You're checking invalid roll no.\nEnter a valid roll no.\nPress Ok to continue.");
            wrongRollAlert.setPositiveButton("Ok",null);
            wrongRollAlert.setCancelable(true);
            wrongRollAlert.create().show();
            wrongRollAlert.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            editRollSearch.setText("");
            editStudentName.setText("");
            editGraduationYear.setText("");
            editBatchYear.setText("");
            editCurrentCity.setText("");
            editProfession.setText("");
            editEmail.setText("");
            editRollNo.setText("");
        }
    }
    public void onClickEditButton(View v) {
        ContentValues values = new ContentValues();
        values.put(DBHandler.NAME,
                editStudentName.getText().toString());
        values.put(DBHandler.YEAR,
                editGraduationYear.getText().toString());
        values.put(DBHandler.BATCH_YEAR,
                editBatchYear.getText().toString());
        values.put(DBHandler.CURRENT_CITY,
                editCurrentCity.getText().toString());
        values.put(DBHandler.PROFESSION,
                editProfession.getText().toString());
        values.put(DBHandler.EMAIL,
                editEmail.getText().toString());
        values.put(DBHandler.ROLL_NO,
                editRollNo.getText().toString());
        String searchByRoll=DBHandler.ROLL_NO+" = ?";
        int editCount=getContentResolver().update(DBHandler.CONTENT_URI,values,searchByRoll,new String[] {editRollSearch.getText().toString()});
        AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
        wrongRollAlert.setTitle("Successfully Deleted!");
        wrongRollAlert.setMessage("The student recorded is edited successfully.\nRecord edited "+editCount+" times.\nPress Ok to continue.");
        wrongRollAlert.setPositiveButton("Ok",null);
        wrongRollAlert.setCancelable(true);
        wrongRollAlert.create().show();
        wrongRollAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        editRollSearch.setText("");
        editStudentName.setText("");
        editGraduationYear.setText("");
        editBatchYear.setText("");
        editCurrentCity.setText("");
        editProfession.setText("");
        editEmail.setText("");
        editRollNo.setText("");
    }
}
