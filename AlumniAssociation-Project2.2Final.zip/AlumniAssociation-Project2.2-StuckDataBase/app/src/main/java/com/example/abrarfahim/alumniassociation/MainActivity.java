package com.example.abrarfahim.alumniassociation;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    EditText editTextInput,searchText;
    TextView textViewText;
    StringBuffer showAll=new StringBuffer();
    public DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
//        editTextInput = (EditText) findViewById(R.id.editTextEditRollCheck);
//        textViewText = (TextView) findViewById(R.id.plainText);
//        dbHandler = new DBHandler(this, null, null, 1);
//        printDatabase();
        textViewText=(TextView) findViewById(R.id.textViewRecord);
        searchText=(EditText) findViewById(R.id.searchText);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                addStudentStartActivity();
            }
        });

        fab.setOnLongClickListener(
                new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        Snackbar.make(v, "TAP PLUS icon to ADD new student", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        return true;
                    }
                }
        );
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        recordCheck();
    }


    @Override
    protected void onResume() {
        super.onResume();
        recordCheck();
    }

    @Override
    protected void onStart() {
        super.onStart();
        recordCheck();
    }

    @Override
    protected void onPause() {
        super.onPause();
        recordCheck();
    }

    @Override
    protected void onStop() {
        super.onStop();
        recordCheck();
    }

    public void onClickFilter(View v) {
//        Intent i=new Intent(this,SearchFilter.class);
//        startActivity(i);
        String URL="content://com.example.abrarfahim.alumniassociation.DBHandler";
//        String showAll;
        Uri students = Uri.parse(URL);
        String basedOnName=DBHandler.NAME+" = ?";
        Cursor c = managedQuery(students, null, null, null, "name");
        if(c==null) {
            AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
            wrongRollAlert.setTitle("Error!");
            wrongRollAlert.setMessage("No record exists.\nAdd at least one student data.\nPress Ok to continue.");
            wrongRollAlert.setPositiveButton("Ok",null);
            wrongRollAlert.setCancelable(true);
            wrongRollAlert.create().show();
            wrongRollAlert.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
        }
        else if(searchText.getText().toString().equals("")) {
            c = managedQuery(students, null, null, null, "name");
            if (c.moveToFirst()) {
                do {
                    showAll.append("Name: "+c.getString(c.getColumnIndex(DBHandler.NAME))+"\n\n"
                            +"Graduation Year: "+c.getString(c.getColumnIndex(DBHandler.YEAR))+"\n\n"
                            +"Batch: "+c.getString(c.getColumnIndex(DBHandler.BATCH_YEAR))+"\n\n"
                            +"Current Profession: "+c.getString(c.getColumnIndex(DBHandler.PROFESSION))+"\n\n"
                            +"Current City: "+c.getString(c.getColumnIndex(DBHandler.CURRENT_CITY))+"\n\n"
                            +"Email: "+c.getString(c.getColumnIndex(DBHandler.EMAIL))+"\n\n"
                            +"Roll No: "+ c.getString(c.getColumnIndex(DBHandler.ROLL_NO))+"\n\n\n\n"+
                            "= = = = = = = = = = = = = = = = = = = = =\n\n\n\n");
                    textViewText.setText(showAll);
                } while (c.moveToNext());
                showAll.delete(0,showAll.length()-1);
            }
        }
        else {
            c = managedQuery(students, null, basedOnName, new String[]{searchText.getText().toString()}, "name");
            if(c==null) {
                AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
                wrongRollAlert.setTitle("Error");
                wrongRollAlert.setMessage("Searched student name is wrong or is not exist.\nTry to enter the name carefully.\nPress Ok to continue.");
                wrongRollAlert.setPositiveButton("Ok",null);
                wrongRollAlert.setCancelable(true);
                wrongRollAlert.create().show();
                wrongRollAlert.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
            }
            else if (c.moveToFirst()) {
                do{
                    showAll.append("Name: "+c.getString(c.getColumnIndex(DBHandler.NAME))+"\n\n"
                            +"Graduation Year: "+c.getString(c.getColumnIndex(DBHandler.YEAR))+"\n\n"
                            +"Batch: "+c.getString(c.getColumnIndex(DBHandler.BATCH_YEAR))+"\n\n"
                            +"Current Profession: "+c.getString(c.getColumnIndex(DBHandler.PROFESSION))+"\n\n"
                            +"Current City: "+c.getString(c.getColumnIndex(DBHandler.CURRENT_CITY))+"\n\n"
                            +"Email: "+c.getString(c.getColumnIndex(DBHandler.EMAIL))+"\n\n"
                            +"Roll No: "+ c.getString(c.getColumnIndex(DBHandler.ROLL_NO))+"\n\n\n\n"+
                            "= = = = = = = = = = = = = = = = = = = = =\n\n\n\n");
                    textViewText.setText(showAll);
                } while (c.moveToNext());
                showAll.delete(0,showAll.length()-1);
            }
        }

    }

    public void addStudentStartActivity() {
        Intent intent = new Intent(this, AddStudent.class);
        startActivity(intent);
    }

    public void addButtonClicked(View view) {
//        Products product = new Products(editTextInput.getText().toString());
//        dbHandler.addProduct(product);
//        printDatabase();
        int a;
    }

    public void deleteButtonClicked(View view) {
//        String inputText = editTextInput.getText().toString();
//        dbHandler.deleteProducts(inputText);
//        printDatabase();
        int b;
    }

    public void printDatabase() {
//        String dbString = dbHandler.databaseToString();
//        textViewText.setText(dbString);
        editTextInput.setText("");
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {
            gotoAddStudent(item);

        } else if (id == R.id.nav_slideshow) {
            gotoEditStudent(item);

        } else if (id == R.id.nav_manage) {
            gotoDeleteStudent(item);

        } else if (id == R.id.nav_share) {
            about(item);

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void gotoAddStudent(MenuItem item) {
        addStudentStartActivity();
    }

    public void gotoEditStudent(MenuItem item) {
        Intent intent = new Intent(this, EditStudent.class);
        startActivity(intent);
    }

    public void gotoDeleteStudent(MenuItem item) {
        Intent intent = new Intent(this, DeleteActivity.class);
        startActivity(intent);
    }
    public void recordCheck() {
        String URL="content://com.example.abrarfahim.alumniassociation.DBHandler";
        Uri students = Uri.parse(URL);
        Cursor c = managedQuery(students, null, null, null, "name");
        if(c==null) {
            textViewText.setText("No record Found.");
        }
        else if (c.moveToFirst()) {
            do{
//                showAll=c.getString(c.getColumnIndex(DBHandler._ID)) +
//                        ", " +  c.getString(c.getColumnIndex(DBHandler.NAME)) +
//                        ", " +  c.getString(c.getColumnIndex(DBHandler.YEAR)) +
//                        ", " +  c.getString(c.getColumnIndex(DBHandler.BATCH_YEAR)) +
//                        ", " +  c.getString(c.getColumnIndex(DBHandler.CURRENT_CITY)) +
//                        ", " +  c.getString(c.getColumnIndex(DBHandler.PROFESSION)) +
//                        ", " +  c.getString(c.getColumnIndex(DBHandler.EMAIL)) +
//                        ", " + c.getString(c.getColumnIndex(DBHandler.ROLL_NO));
                showAll.append("Name: "+c.getString(c.getColumnIndex(DBHandler.NAME))+"\n\n"
                        +"Graduation Year: "+c.getString(c.getColumnIndex(DBHandler.YEAR))+"\n\n"
                        +"Batch: "+c.getString(c.getColumnIndex(DBHandler.BATCH_YEAR))+"\n\n"
                        +"Current Profession: "+c.getString(c.getColumnIndex(DBHandler.PROFESSION))+"\n\n"
                        +"Current City: "+c.getString(c.getColumnIndex(DBHandler.CURRENT_CITY))+"\n\n"
                        +"Email: "+c.getString(c.getColumnIndex(DBHandler.EMAIL))+"\n\n"
                        +"Roll No: "+ c.getString(c.getColumnIndex(DBHandler.ROLL_NO))+"\n\n\n\n"+
                        "= = = = = = = = = = = = = = = = = = = = =\n\n\n\n");
                textViewText.setText(showAll);
            } while (c.moveToNext());
            showAll.delete(0,showAll.length()-1);
        }
    }
    public void about(MenuItem m) {
        AlertDialog.Builder wrongRollAlert=new AlertDialog.Builder(this);
        wrongRollAlert.setTitle("About!");
        wrongRollAlert.setMessage("This application is made by these people,\nAbrar Fahim, Kajal, Mippa, Lima, Shilpi, Piya, Zubair.\nPress Ok to continue.");
        wrongRollAlert.setPositiveButton("Ok",null);
        wrongRollAlert.setCancelable(true);
        wrongRollAlert.create().show();
        wrongRollAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
    }
}
