# AlumniAssociation-Project2.2
An android application about Alumni Association. Using Android Studio.
