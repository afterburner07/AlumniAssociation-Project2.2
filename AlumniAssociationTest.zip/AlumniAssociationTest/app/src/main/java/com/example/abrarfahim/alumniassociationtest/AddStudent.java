package com.example.abrarfahim.alumniassociationtest;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddStudent extends AppCompatActivity {
    EditText editStudentName,editGraduationYear,editBatchYear,editCurrentCity,editProfession,editEmail,editRollNo;
    String StudentName,GraduationYear,BatchYear,CurrentCity,Profession,email,rollNo;
    Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);
        editStudentName=(EditText) findViewById(R.id.editTextEditRollCheck);
        editGraduationYear=(EditText) findViewById(R.id.editTextGraduationYear);
        editBatchYear=(EditText) findViewById(R.id.editText5);
        editCurrentCity=(EditText) findViewById(R.id.editTextCurrentCity);
        editProfession=(EditText) findViewById(R.id.editTextProfession);
        editEmail=(EditText) findViewById(R.id.editText7);
        editRollNo=(EditText) findViewById(R.id.editTextRollNo);
        addButton=(Button) findViewById(R.id.button2);
//        addButton.setOnLongClickListener(new Button.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                ;
//                return true;
//            }
//        });
    }

    public void onClickBackButton(View v) {
        finish();
    }

    public void onClickAddButton(View v) {
        // Add a new student record
        ContentValues values = new ContentValues();
        values.put(DBHandler.NAME,
                editStudentName.getText().toString());
        values.put(DBHandler.YEAR,
                editGraduationYear.getText().toString());
        values.put(DBHandler.BATCH_YEAR,
                editBatchYear.getText().toString());
        values.put(DBHandler.CURRENT_CITY,
                editCurrentCity.getText().toString());
        values.put(DBHandler.PROFESSION,
                editProfession.getText().toString());
        values.put(DBHandler.EMAIL,
                editEmail.getText().toString());
        values.put(DBHandler.ROLL_NO,
                editRollNo.getText().toString());

//        values.put(DBHandler.GRADE,
//                ((EditText)findViewById(R.id.editText3)).getText().toString());

        Uri uri = getContentResolver().insert(
                DBHandler.CONTENT_URI, values);

        Toast.makeText(getBaseContext(),
                uri.toString(), Toast.LENGTH_LONG).show();
    }
}
